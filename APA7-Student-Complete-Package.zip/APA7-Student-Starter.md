<!--
APA 7 STUDENT PAPER STARTER FOR iA WRITER

1. Edit every bracketed field.
2. Keep the title page as raw HTML; it supplies the course and due-date fields
   that iA Writer's built-in title variables do not provide.
3. Choose the “APA 7 Student” template for Preview, Print, or PDF export.
4. Use a US Letter page size when the export dialog offers a page-size choice.
5. Delete this comment before submission if desired; it is not printed.
-->

<section class="apa-title-page">
  <div class="apa-title-block">
    <h1 class="apa-paper-title">[Full Title of the Paper]</h1>
    <p>Pengzhao Xie</p>
    <p>Warner School of Education and Human Development, University of Rochester</p>
    <p>[COURSE 000: Course Name]</p>
    <p>[Instructor Name]</p>
    <p>[Month Day, Year]</p>
  </div>
</section>

# [Full Title of the Paper]

Begin the paper here. Ordinary paragraphs receive a 0.5-inch first-line indent automatically. The template uses 12-point Times New Roman, double spacing, and APA 7 student-paper page numbering.

## [Level 2 Heading]

Continue the paper here.

### [Level 3 Heading]

Continue the paper here.

#### [Level 4 Run-In Heading]

The paragraph begins on the same line as the Level 4 heading when exported.

##### [Level 5 Run-In Heading]

The paragraph begins on the same line as the Level 5 heading when exported.

<!-- OPTIONAL ABSTRACT: remove the surrounding comment markers and place this
immediately after the title-page section. Keep the page-break helper so the
paper title begins on the following page.

# Abstract

<p class="apa-abstract">[Write the abstract as one unindented paragraph.]</p>
<p class="apa-keywords"><em>Keywords:</em> [keyword one], [keyword two], [keyword three]</p>
<div class="page-break"></div>
-->

# References

Author, A. A., & Author, B. B. (Year). Title of the article. *Title of Periodical, volume*(issue), xx-xx. https://doi.org/xx.xxxxxxxxxx

Author, C. C. (Year). *Title of book*. Publisher.
