(() => {
  "use strict";

  const normalizedText = (element) =>
    (element && element.textContent ? element.textContent : "")
      .replace(/\s+/g, " ")
      .trim();

  function markNewPages(body) {
    body.querySelectorAll("h1").forEach((heading) => {
      const text = normalizedText(heading);
      if (/^(References|Footnotes|Tables|Figures|Appendix(?:es)?(?:\s+[A-Z])?)$/i.test(text)) {
        heading.classList.add("apa-new-page");
      }
    });
  }

  function markReferences(body) {
    let inReferences = false;
    Array.from(body.children).forEach((element) => {
      if (/^H1$/i.test(element.tagName)) {
        inReferences = /^References$/i.test(normalizedText(element));
        return;
      }
      if (!inReferences) return;
      if (element.matches("p")) {
        element.classList.add("apa-reference");
      }
    });
  }

  function markTables(body) {
    body.querySelectorAll("table").forEach((table) => {
      const title = table.previousElementSibling;
      const number = title && title.previousElementSibling;
      if (number && number.matches("p") && /^Table\s+\d+[A-Za-z]?$/i.test(normalizedText(number))) {
        number.classList.add("apa-table-number");
        if (title && title.matches("p")) title.classList.add("apa-table-title");
      }
      const note = table.nextElementSibling;
      if (note && note.matches("p") && /^Note\./i.test(normalizedText(note))) {
        note.classList.add("apa-table-note");
      }
    });
  }

  function markFigures(body) {
    body.querySelectorAll("figure, p > img:only-child").forEach((candidate) => {
      const figure = candidate.matches("figure") ? candidate : candidate.parentElement;
      const title = figure.previousElementSibling;
      const number = title && title.previousElementSibling;
      if (number && number.matches("p") && /^Figure\s+\d+[A-Za-z]?$/i.test(normalizedText(number))) {
        number.classList.add("apa-figure-number");
        if (title && title.matches("p")) title.classList.add("apa-figure-title");
      }
      const note = figure.nextElementSibling;
      if (note && note.matches("p") && /^Note\./i.test(normalizedText(note))) {
        note.classList.add("apa-figure-note");
      }
    });
  }

  function enhance() {
    const body = document.body;
    if (!body || !body.matches("[data-document]")) return;
    markNewPages(body);
    markReferences(body);
    markTables(body);
    markFigures(body);
  }

  document.addEventListener("DOMContentLoaded", () => {
    enhance();
    if (document.body) {
      document.body.addEventListener("ia-writer-change", enhance);
    }
  });
})();
